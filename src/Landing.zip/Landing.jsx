import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { FaFacebook, FaTwitter, FaInstagram } from 'react-icons/fa';

const Landing = () => {
  const [productos, setProductos] = useState([]);
  const [carrito, setCarrito] = useState([]);
  const [carritoVisible, setCarritoVisible] = useState(false);

  useEffect(() => {
    fetchProductos();
  }, []);

  const fetchProductos = async () => {
    try {
      const response = await axios.get('http://localhost:3000/productos');
      setProductos(response.data);
    } catch (error) {
      console.error('Error fetching productos:', error);
    }
  };

  const agregarAlCarrito = (producto) => {
    const cantidad = prompt(`¿Cuántos ${producto.nombre} deseas agregar al carrito?`, '1');
    if (cantidad) {
      const item = {
        ...producto,
        cantidad: parseInt(cantidad)
      };
      setCarrito([...carrito, item]);
    }
  };

  const realizarCompra = async (productos) => {
    try {
      const fechaCompra = new Date().toISOString().slice(0, 19).replace('T', ' ');

      const productosParaComprar = productos.map(item => ({
        id_compra: null,
        fecha_compra: fechaCompra,
        nombre_producto: item.nombre,
        cantidad: item.cantidad,
        precio: item.precio,
        total_compra: item.precio * item.cantidad,
        categoria_producto: item.categoria || null
      }));

      console.log('Datos de compra:', { productos: productosParaComprar });

      await axios.post('http://localhost:3000/api/compras', { productos: productosParaComprar });

      alert('Compra realizada correctamente!');
      setCarrito([]);
    } catch (error) {
      console.error('Error al realizar la compra:', error);
      alert('Error al realizar la compra. Por favor, intenta nuevamente.');
    }
  };

  const comprarAhora = (producto) => {
    const cantidad = prompt(`¿Cuántos ${producto.nombre} deseas comprar?`, '1');
    if (cantidad) {
      const item = {
        ...producto,
        cantidad: parseInt(cantidad)
      };
      realizarCompra([item]);
    }
  };

  const toggleCarrito = () => {
    setCarritoVisible(!carritoVisible);
  };

  const editarCantidad = (index) => {
    const nuevaCantidad = prompt("Ingresa la nueva cantidad:", carrito[index].cantidad);
    if (nuevaCantidad) {
      const nuevoCarrito = [...carrito];
      nuevoCarrito[index].cantidad = parseInt(nuevaCantidad);
      setCarrito(nuevoCarrito);
    }
  };

  const eliminarProducto = (index) => {
    const confirmacion = window.confirm("¿Seguro que quieres eliminar este artículo?");
    if (confirmacion) {
      const nuevoCarrito = carrito.filter((item, i) => i !== index);
      setCarrito(nuevoCarrito);
    }
  };

  return (
    <div style={styles.landing}>
      <header style={styles.header}>
        <div style={styles.logo}>
          <img src="image/logo_pizza2.png" alt="Pizzeria Saborreti" style={styles.logoImg} />
          <h1 style={styles.logoText}>Pizzeria Saborreti</h1>
        </div>
        <nav style={styles.nav}>
          <button onClick={toggleCarrito} style={styles.navButton}>
            {carritoVisible ? 'Cerrar Carrito' : 'Ver Carrito'}
          </button>
          <div style={{ ...styles.carritoDrawer, ...(carritoVisible ? styles.carritoDrawerOpen : {}) }}>
            <h2 style={styles.carritoTitulo}>Carrito de Compras</h2>
            {carrito.length === 0 ? (
              <p style={styles.carritoTexto}>El carrito está vacío</p>
            ) : (
              <>
                <ul style={styles.carritoList}>
                  {carrito.map((item, index) => (
                    <li key={index} style={styles.carritoItem}>
                      <p style={styles.carritoTexto}>{item.nombre}</p>
                      <p style={styles.carritoTexto}>Cantidad: {item.cantidad}</p>
                      <div style={styles.carritoButtonContainer}>
                        <button onClick={() => editarCantidad(index)} style={styles.carritoButton}>Editar Cantidad</button>
                        <button onClick={() => eliminarProducto(index)} style={styles.carritoButton}>Eliminar</button>
                      </div>
                    </li>
                  ))}
                </ul>
                <p style={styles.carritoTexto}>Total: ${carrito.reduce((total, item) => total + item.precio * item.cantidad, 0)}</p>
                <button onClick={() => realizarCompra(carrito)} style={styles.carritoButton}>Realizar Compra</button>
              </>
            )}
          </div>
        </nav>
      </header>

      <div style={styles.mainContent}>
        <aside style={styles.categorias}>
          <h2 style={styles.categoriasTitulo}>Categorías</h2>
          <ul style={styles.categoriasList}>
            <li style={styles.categoriasItem}>Todos</li>
            <li style={styles.categoriasItem}>Sencillas</li>
            <li style={styles.categoriasItem}>Especiales</li>
            <li style={styles.categoriasItem}>VIP</li>
          </ul>
        </aside>
        <section style={styles.productosSection}>
          <h2 style={styles.h2}>Nuestros Productos</h2>
          <div style={styles.productosGrid}>
            {productos.map((producto) => (
              <div key={producto.id_producto} style={styles.productoCard}>
              <img 
                src={producto.imagen ? `http://localhost:3000/uploads/${producto.imagen}` : 'image/default-pizza.jpg'} 
                alt={producto.nombre} 
                style={styles.productoImagen} 
              />
              <div style={styles.productoInfo}>
                <h3 style={styles.productoTitulo}>{producto.nombre}</h3>
                <div style={styles.productoDescripcionContainer}>
                  <p style={styles.productoDescripcion}>{producto.descripcion}</p>
                </div>
                <p style={styles.productoTamano}>Tamaño: {producto.tamano}</p>
                <p style={styles.productoPrecio}>Precio: ${producto.precio}</p>
                <div style={styles.productoButtonContainer}>
                  <button onClick={() => agregarAlCarrito(producto)} style={styles.productoButton}>Agregar al Carrito</button>
                  <button onClick={() => comprarAhora(producto)} style={styles.productoButton}>Comprar Ahora</button>
                </div>
              </div>
            </div>
            ))}
          </div>
        </section>
      </div>

      <footer style={styles.footer}>
        <div style={styles.footerContent}>
          <p style={styles.footerText}>Dirección: Calle Falsa 123, Ciudad, País</p>
          <p style={styles.footerText}>Teléfonos: +1 234 567 8900</p>
          <p style={styles.footerText}>Redes Sociales:</p>
          <ul style={styles.socialMediaList}>
            <li><a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer" style={styles.socialMediaLink}><FaFacebook /></a></li>
            <li><a href="https://www.twitter.com" target="_blank" rel="noopener noreferrer" style={styles.socialMediaLink}><FaTwitter /></a></li>
            <li><a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer" style={styles.socialMediaLink}><FaInstagram /></a></li>
          </ul>
        </div>
      </footer>
    </div>
  );
};

const styles = {
  landing: {
    padding: '0',
    backgroundColor: '#f4f4f4',
    minHeight: '100vh',
    width: '100vw',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    boxSizing: 'border-box',
    overflowX: 'hidden',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#1446A0',
    color: 'white',
    padding: '10px 20px',
    width: '100%',
    boxSizing: 'border-box',
  },
  logo: {
    display: 'flex',
    alignItems: 'center',
  },
  logoImg: {
    height: '50px',
    marginRight: '10px',
  },
  logoText: {
    color: '#fff',
    fontSize: '1.5em',
    fontWeight: 'bold',
  },
  nav: {
    position: 'relative',
  },
  navButton: {
    backgroundColor: '#fff',
    color: '#333',
    border: 'none',
    padding: '10px 20px',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '1em',
  },
  mainContent: {
    display: 'flex',
    width: '100%',
    maxWidth: '1200px',
    boxSizing: 'border-box',
  },
  categorias: {
    width: '200px',
    padding: '20px',
    backgroundColor: '#F54703',
    color: 'white',
  },
  categoriasTitulo: {
    fontSize: '1.5em',
    fontWeight: 'bold',
    marginBottom: '10px',
  },
  categoriasList: {
    listStyle: 'none',
    padding: '0',
  },
  categoriasItem: {
    marginBottom: '10px',
    cursor: 'pointer',
  },
  productosSection: {
    flexGrow: 1,
    padding: '20px',
  },
  h2: {
    color: 'black',
    textAlign: 'center',
    fontSize: '2em',
    fontWeight: 'bold',
    marginBottom: '20px',
  },
  productosGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
    gap: '20px',
  },
  productoCard: {
    backgroundColor: '#fff',
    borderRadius: '8px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    overflow: 'hidden',
    display: 'flex',
    flexDirection: 'column',
    height: '100%', // Asegura que todas las tarjetas tengan la misma altura
  },
  productoImagen: {
    width: '100%',
    height: '200px',
    objectFit: 'cover',
  },
  productoInfo: {
    display: 'flex',
    flexDirection: 'column',
    flexGrow: 1,
    padding: '10px',
  },
  productoTitulo: {
    color: 'black',
    fontSize: '1.25em',
    fontWeight: 'bold',
    margin: '10px 0',
  },
  productoDescripcionContainer: {
    flexGrow: 1,
    overflowY: 'auto',
    maxHeight: '100px', // Ajusta este valor según tus necesidades
  },
  productoDescripcion: {
    color: 'black',
    fontSize: '1em',
    margin: '0',
  },
  productoTamano: {
    color: 'black',
    fontSize: '1em',
    margin: '10px 0 0 0',
  },
  productoPrecio: {
    fontSize: '1.25em',
    fontWeight: 'bold',
    color: '#FD9661',
    margin: '10px 0',
  },
  productoButtonContainer: {
    display: 'flex',
    justifyContent: 'space-between',
    marginTop: 'auto',
  },
  productoButton: {
    backgroundColor: '#333',
    color: '#fff',
    border: 'none',
    padding: '10px 20px',
    margin: '10px 5px',
    borderRadius: '4px',
    cursor: 'pointer',
    flexGrow: 1,
  },
  carritoDrawer: {
    position: 'absolute',
    top: '100%',
    right: '0',
    width: '300px',
    maxHeight: '0',
    overflow: 'hidden',
    backgroundColor: '#fff',
    color: 'black',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    transition: 'max-height 0.3s ease-in-out',
    zIndex: '10',
  },
  carritoDrawerOpen: {
    maxHeight: '400px',
    padding: '20px',
    boxSizing: 'border-box',
  },
  carritoTitulo: {
    fontSize: '1.5em',
    fontWeight: 'bold',
    marginBottom: '10px',
  },
  carritoTexto: {
    marginBottom: '10px',
  },
  carritoList: {
    listStyle: 'none',
    padding: '0',
    marginBottom: '10px',
  },
  carritoItem: {
    marginBottom: '10px',
  },
  carritoButtonContainer: {
    display: 'flex',
    justifyContent: 'space-between',
  },
  carritoButton: {
    backgroundColor: '#333',
    color: '#fff',
    border: 'none',
    padding: '5px 10px',
    borderRadius: '4px',
    cursor: 'pointer',
  },
  footer: {
    backgroundColor: '#F54703',
    color: 'white',
    padding: '10px 20px',
    width: '100%',
    boxSizing: 'border-box',
    display: 'flex',
    justifyContent: 'center',
  },
  footerContent: {
    textAlign: 'center',
  },
  footerText: {
    margin: '5px 0',
  },
  socialMediaList: {
    display: 'flex',
    justifyContent: 'center',
    listStyle: 'none',
    padding: '0',
    marginTop: '10px',
  },
  socialMediaLink: {
    color: 'white',
    fontSize: '1.5em',
    margin: '0 10px',
  },
};

export default Landing;